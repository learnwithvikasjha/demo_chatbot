import requests
import json
import re
import csv
from io import StringIO

github_raw_csv_url = "https://raw.githubusercontent.com/learnwithvikasjha/demo_chatbot/main/qna.csv"
token = '1856449076:AAGJx8SNqD37ASgIET7XZhwhVyutuU6H4Z8'
allowed_urls_list = ["grafana.com","bmc.com"]

def load_qna():
    url = github_raw_csv_url
    data = {}
    response = requests.get(url)
    if response.status_code == 200:
        content = response.text
        # Use StringIO to create a file-like object from the string content
        csv_file = StringIO(content)
        # Read the CSV file
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            data[row['Question']] = row['Response']
    else:
        print("Failed to fetch data")
    return data

def call_logger(reply_msg):
    to_url = 'https://api.telegram.org/bot{}/sendMessage?chat_id={}&text={}&parse_mode=HTML'.format(token, "350907917", reply_msg)
    resp = requests.get(to_url)

def find_urls(text):
    pattern = r'\b(?:(?:https?|ftp)://|www\.)?[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?:/\S*)?\b'
    return re.findall(pattern, text)

def user_status(chat_id, user_id):
    base_url = 'https://api.telegram.org/bot{}/getChatMember'.format(token)
    data = { "chat_id" : chat_id, "user_id" : user_id }
    resp = requests.post(base_url, data=data)
    data = resp.json()
    print(data)
    return data["result"]["status"]

def delete_msg(message_id, chat_id):
    data = {"message_id" : message_id, "chat_id" : chat_id }
    to_url = 'https://api.telegram.org/bot{}/deleteMessage'.format(token)
    resp = requests.post(to_url, data=data)

def contains_bad_words(message):
    bad_words = ["fuck", "shit"]
    for word in bad_words:
        if word in message.lower():
            return "yes"
    return "no"

def auto_response(message):
    qna = load_qna()
    if message in qna:
        response = qna[message]
        return response
    else:
        return 'No matching response found'

def reply(token, chat_id, reply_msg, message_id):
    call_logger("Inside reply function now...")
    if reply_msg:
        to_url = 'https://api.telegram.org/bot{}/sendMessage?chat_id={}&text={}&reply_to_message_id={}&parse_mode=HTML'.format(token, chat_id, reply_msg, message_id)
        resp = requests.get(to_url)
    call_logger("reply function executed successfully")

def welcome_new_member(item):
    try:
        chat_id = item["chat"]["id"]
        user_id = item["new_chat_member"]["id"]
        message_id = item.get("message",{}).get("message_id",{})
        user_name = item["new_chat_member"].get("first_name",str(user_id))
        title = item["chat"].get("title", "title not available")
        if "vikasjha001_bot" in user_name:
            r.hset("botaddedin", str(chat_id) + '_' + str(user_id) , "{}".format(title) )
        else:
            msg = auto_response("welcome")
            welcome_msg = '''<a href="tg://user?id={}">@{}</a> %0a {} '''.format(user_id, user_name, msg)
            to_url = 'https://api.telegram.org/bot{}/sendMessage?chat_id={}&text={}&parse_mode=HTML'.format(token, chat_id, welcome_msg)
            resp = requests.get(to_url)
        print("finished welcome msg")
        del_message_id = r.hget("welcome_user", chat_id)
        delete_msg(del_message_id, chat_id)
        r.hset("welcome_user", chat_id, message_id)

    except Exception as e:
        call_logger(dict)
        call_logger(e)
        print("error from welcome_new_member function: {}".format(e))        

def handle_message(data):
    try:
        if "new_chat_member" in data["message"]:
            print("condition is true")
            welcome_new_member(data["message"])
        else:
            chat_id = data.get("message", {}).get("chat", {}).get("id")
            message_id = data.get("message",{}).get("message_id",{})
            user_id = data.get("message", {}).get("from",{}).get("id",{})
            first_name = data.get("message", {}).get("from",{}).get("first_name", user_id)
            user_name = data.get("message", {}).get("from",{}).get("username",first_name)
            message = data.get("message", {}).get("text", {})
            print(f"chat_id: {chat_id}, message_id: {message_id}, user_id:  {user_id}, first_name: {first_name}, user_name: {user_name}")
            urls = find_urls(message)
            has_urls = 1 if len(urls) > 0 else 0
            print("message contains urls") if has_urls == 1 else None
            user_type = user_status(chat_id, user_id)
            reply_msg = ""
            if has_urls == 1 and user_type in ("creator", "administrator"):
                reply_msg = message
            elif has_urls == 1:
                delete_msg(message_id, chat_id)
                ban_user(chat_id, user_id)
            else:
                print("Calling auto response function..")
                reply_msg = auto_response(message)
                print(reply_msg)
            if contains_bad_words(message) == "yes":
                delete_msg(message_id, chat_id)
            else:
                reply(token, chat_id, reply_msg, message_id)
        return {'statusCode': 200, 'message': 'Received and processed message successfully'}
    except Exception as e:
        print(e)
        # call_logger("error is: {}".format(e))
        return {'statusCode': 200, 'message': f'{e}'}


def lambda_handler(event, context):
    print(event)
    if 'body' in event:
        handle_message(json.loads(event['body']))
    else:
        print("no data received")
    return {'statusCode': 200}